#!/bin/bash
tr '\r' '\n' < ADA073408-Table1.csv | grep -v "\[DONE\]" > ADA073408-Table1-UnixEndings.csv
tr '\r' '\n' < ADA073408-Table2.csv > ADA073408-Table2-UnixEndings.csv
tr '\r' '\n' < ADA073408-Table3.csv | grep -v "REGION NUM" > ADA073408-Table3-UnixEndings.csv
awk -F, 'BEGIN {widthlist = "5 5 10 10 10 10 10 10 10"; split (widthlist, widths, " ")}{for(i=1;i<=NF;i++){printf "%-*s", widths[i],$i};printf "\n"}' ADA073408-Table1-UnixEndings.csv > SolidTable
awk -F, 'BEGIN {widthlist = "5 5 5 5 5 5 5 5 5 5 10"; split (widthlist, widths, " ")}{for(i=1;i<=NF;i++){if (i > 1 || i < NF) { printf "  "; } printf "%-*s", widths[i],$i};printf "\n"}' ADA073408-Table2-UnixEndings.csv > RegionTable
awk -F, 'BEGIN {widthlist = "5 5 5 5 5 44"; split (widthlist, widths, " "); remaplist = "1 2 3 5 6 4"; split (remaplist, remaps, " ")}{for(i=1;i<=NF;i++){printf "%-*s", widths[i],$remaps[i]};printf "\n"}' ADA073408-Table3-UnixEndings.csv > IdentTable
echo "in ADA073408 table" > ADA073408
echo "282  282  " >> ADA073408
cat SolidTable >> ADA073408
cat RegionTable >> ADA073408
echo "-1" >> ADA073408
cat IdentTable >> ADA073408
echo "                                                                                " >> ADA073408
#comgeom-g -d 1 -v 5 ADA073408 ADA073408.g
